<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'wordpress' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '52O:JcvZq&$p1y$y/]^hW,gy<z:;fb;Rqxsw{hSMAr#Vh4sdb8c(eV@x]vr=L>4&' );
define( 'SECURE_AUTH_KEY',  'Z(,jOT ,BzPgM:hpznZ%G{b>HC;2kCP%<|Bri&2Z;&B4S3C64=yqNCme%=K>Hd]O' );
define( 'LOGGED_IN_KEY',    'QCHN/H.BJjel@ZUri+<Po`BY:{f3T,ELm.s)Eh&T_|+m}rh&gLQ5F9LM5q)xvfkl' );
define( 'NONCE_KEY',        'Ia7g::~WN,QAVK^}xEbPUR4ddKnUq?nw2QDM2Nd$.o/Y+8_,d2xB#FKbqjr?(oUu' );
define( 'AUTH_SALT',        '/mJ6M2^SkOJ@cu5e]Ylq;ic=NZ}B]8HMG$EP1FMZkHRP~?z!IE}O2&M-EwaZw`eL' );
define( 'SECURE_AUTH_SALT', '|u7Zl6N$]k(jr4.C</P>Ny[efoRbbugRwZN=qp+1NKjH?/zNEgoNI/+QD#UMV1Rj' );
define( 'LOGGED_IN_SALT',   'Xd5A{@G7I1m#j#TxEd}7ab|Ax5V2-71Ftb0Hz9}QBa5Fg{uq:Gm]P=4E&XRlT$;2' );
define( 'NONCE_SALT',       'NI|hizTbcF*pVR8)Q_wVl:!brK8%K]k4*}^VDAho,VW}i/c66gwzU<(1=VRsF,2q' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
